const tbody = document.querySelector("tbody");
function renderTabel() {
    tbody.innerHTML = "";
    dataKatalogBuku.forEach(buku => {
        tbody.innerHTML += `
        <tr>
            <td><img src="${buku.cover}" alt="${buku.namaBarang}" class="thumb"></td>
            <td>${buku.kodeBarang}</td>
            <td>${buku.namaBarang}</td>
            <td>${buku.jenisBarang}</td>
            <td>${buku.edisi}</td>
            <td>${buku.stok}</td>
            <td>${buku.harga}</td>
        </tr>`;
    });
}
renderTabel();


document.getElementById("tambahBtn").addEventListener("click", () => {
    const kode = prompt("Masukkan kode barang:");
    const nama = document.getElementById("judulBaru").value;
    const jenis = prompt("Masukkan jenis barang:");
    const edisi = prompt("Masukkan edisi:");
    const stok = document.getElementById("stokBaru").value;
    const harga = document.getElementById("hargaBaru").value;
    const cover = prompt("Masukkan URL cover (misal: assets/nama.jpg):");

    if (!kode || !nama || !stok || !harga || !cover) {
    alert("Lengkapi semua data buku baru!");
    return;
    }

    dataKatalogBuku.push({
    kodeBarang: kode,
    namaBarang: nama,
    jenisBarang: jenis || "Buku Ajar",
    edisi: edisi || "1",
    stok: parseInt(stok),
    harga: harga,
    cover: cover
    });
    renderTabel();
});