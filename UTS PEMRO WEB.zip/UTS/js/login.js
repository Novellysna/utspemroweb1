document.getElementById("loginForm").addEventListener("submit", (e) => {
e.preventDefault();
const email = document.getElementById("email").value.trim();
const pass = document.getElementById("password").value.trim();

const pengguna = dataPengguna.find(u => u.email === email && u.password === pass);

if (pengguna) {
alert(`Selamat datang, ${pengguna.nama}!`);
localStorage.setItem("userActive", JSON.stringify(pengguna));
window.location.href = "dashboard.html";
} else {
alert("Email atau password salah, silakan coba lagi.");
}
});

const modal = document.getElementById("modal");
const closeModal = document.getElementById("closeModal");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");

document.getElementById("forgotBtn").onclick = () => {
modal.style.display = "flex";
modalTitle.textContent = "Lupa Password";
modalBody.innerHTML = `Silakan hubungi <strong>Admin</strong> melalui email <a href='mailto:admin@tokobuku.com'>admin@tokobuku.com</a> untuk melakukan reset password.`;
};

document.getElementById("signupBtn").onclick = () => {
modal.style.display = "flex";
modalTitle.textContent = "Form Pendaftaran";
modalBody.innerHTML = `Pendaftaran akun baru hanya dilakukan oleh <strong>Admin</strong>. Hubungi admin untuk membuat akun.`;
};

closeModal.onclick = () => (modal.style.display = "none");
window.onclick = (e) => { if (e.target == modal) modal.style.display = "none"; };