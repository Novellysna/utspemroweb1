const hasil = document.getElementById("hasil");
const cariBtn = document.getElementById("btnCari");

cariBtn.addEventListener("click", () => {
    const nomor = document.getElementById("doNum").value.trim();
    const data = dataTracking[nomor];

    if (!data) {
        hasil.innerHTML = `<p>Nomor DO tidak ditemukan.</p>`;
        return;
    }

    let perjalananHTML = data.perjalanan
        .map(item => `
            <div class='progress-step'>
                <div class='time'>${item.waktu}</div>
                <div class='desc'>${item.keterangan}</div>
            </div>`)
        .join("");

    hasil.innerHTML = `
        <div class="tracking-box">
            <h3>Nomor DO: ${data.nomorDO}</h3>
            <p><strong>Nama Pemesan:</strong> ${data.nama}</p>
            <p><strong>Status:</strong> ${data.status}</p>
            <p><strong>Ekspedisi:</strong> ${data.ekspedisi}</p>
            <p><strong>Tanggal Kirim:</strong> ${data.tanggalKirim}</p>
            <p><strong>Kode Paket:</strong> ${data.paket}</p>
            <p><strong>Total Pembayaran:</strong> ${data.total}</p>
            <h4>Riwayat Perjalanan:</h4>
            <div class='timeline'>${perjalananHTML}</div>
        </div>
    `;
});